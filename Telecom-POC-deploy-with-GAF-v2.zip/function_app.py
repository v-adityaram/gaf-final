"""Telecom-POC + GAF-POC mock APIs, both on the Azure Functions v2
programming model, in one Function App (Consumption plan bills per
execution regardless of how many apps host the routes, and a demo with no
security-isolation need gets nothing from a second Storage
Account/Application Insights pair -- so this is one app, two unrelated
route groups).

All subscriber/customer identifiers and commercial data in this module are
fictional. The response envelopes are intentionally suitable for future
replacement by Azure AI Foundry tools, CRM services, billing systems, and
product catalogues.

The GAF section below (routes under /api/gaf/...) is deliberately
info-only: eight read-only lookups covering both agents from the GAF
Prototype Build Brief --

  Smart Order Helper:      products, inventory, customers, orders
  Product & Warranty Advisor: documents, product-approval, warranty-rules,
                               escalation-rules

Order-building, confirmation, and escalation *decisions* are orchestration
logic that belongs in the calling app (same separation telecom-assistant
already keeps: this Function App is a data source, never the thing that
decides or acts). Sample data is transcribed directly from the brief's own
Data Sets A-I -- not invented -- so it matches gaf_demo's local JSON/docs
where those already exist.
"""

import json
import logging
import re
from datetime import UTC, datetime
from typing import Any, Callable

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)
logger = logging.getLogger(__name__)


class SubscriberRequestError(ValueError):
    """A client error caused by missing or unsupported subscriber context."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


def json_response(payload: dict[str, Any], status_code: int = 200) -> func.HttpResponse:
    """Return a consistently encoded JSON response."""
    return func.HttpResponse(
        json.dumps(payload, ensure_ascii=False),
        status_code=status_code,
        mimetype="application/json",
    )


SUBSCRIBERS = {
    f"+9199999000{i:02d}": {
        "customerId": f"CUST-IN-{i:04d}",
        "msisdn": f"+9199999000{i:02d}",
        "circle": ["Karnataka", "Maharashtra", "Delhi", "Tamil Nadu", "Gujarat",
                   "West Bengal", "Telangana", "Kerala", "Rajasthan", "Uttar Pradesh"][i - 1],
        "subscriberType": "Prepaid" if i % 2 else "Postpaid",
        "planPrice": 199.0 + i * 20,
        "balance": 50.0 + i * 17.5,
        "language": ["en-IN", "hi-IN", "mr-IN", "ta-IN", "gu-IN",
                     "bn-IN", "te-IN", "ml-IN", "hi-IN", "hi-IN"][i - 1],
        "device": [
            ("Samsung", "Galaxy A54 5G"), ("Apple", "iPhone 15"),
            ("OnePlus", "Nord CE 4"), ("Xiaomi", "Redmi Note 13 Pro"),
            ("Motorola", "Edge 50 Fusion"), ("Nothing", "Phone (2a)"),
            ("Google", "Pixel 8a"), ("Vivo", "V30 5G"),
            ("Oppo", "Reno 11 5G"), ("Realme", "12 Pro 5G"),
        ][i - 1],
    }
    for i in range(1, 11)
}


def subscriber_for(req: func.HttpRequest) -> dict[str, Any]:
    """Require and resolve one of the ten configured mock subscribers."""
    requested = req.params.get("msisdn") or req.params.get("mobileNumber")
    if not requested or not requested.strip():
        raise SubscriberRequestError(
            "The mobileNumber query parameter is required.", 400
        )

    # A literal '+' in a URL query may be decoded as a space. Normalizing to
    # digits supports both '?mobileNumber=+91...' and the encoded '%2B91...'.
    digits = re.sub(r"\D", "", requested)
    number = f"+{digits}"
    if number not in SUBSCRIBERS:
        raise SubscriberRequestError(
            "Unknown mobileNumber. Use +919999900001 through +919999900010.",
            404,
        )
    return SUBSCRIBERS[number]


def personalize(data: dict[str, Any], subscriber: dict[str, Any]) -> dict[str, Any]:
    """Apply deterministic per-subscriber differences while retaining API contracts."""
    index = int(subscriber["customerId"][-4:])
    data = json.loads(json.dumps(data))
    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key == "msisdn": value[key] = subscriber["msisdn"]
                elif key == "customerId": value[key] = subscriber["customerId"]
                elif key == "telecomCircle" or key == "lastKnownCircle": value[key] = subscriber["circle"]
                elif key == "subscriberType": value[key] = subscriber["subscriberType"]
                elif key == "preferredLanguage": value[key] = subscriber["language"]
                elif key == "manufacturer": value[key] = subscriber["device"][0]
                elif key == "model": value[key] = subscriber["device"][1]
                elif key == "imei": value[key] = f"350000000000{index:03d}"
                elif key == "iccid": value[key] = f"8991000000000000{index:04d}"
                elif key == "imsi": value[key] = f"40400000000{index:04d}"
                elif key in {"id", "productId"} and isinstance(item, str): value[key] = f"{item}-{index:02d}"
                elif key == "price" and isinstance(item, (int, float)): value[key] = subscriber["planPrice"] if "planId" in value else item + index * 3
                elif key == "amount" and isinstance(item, (int, float)): value[key] = item + index * 2
                elif key == "balance" and isinstance(item, (int, float)): value[key] = subscriber["balance"]
                elif key in {"usedMB", "usedMinutes", "used", "balance"} and isinstance(item, (int, float)): value[key] = item + index * 10
                else: visit(item)
        elif isinstance(value, list):
            for item in value: visit(item)
    visit(data)
    return data


def api_handler(
    operation: str, req: func.HttpRequest, payload_factory: Callable[[], dict[str, Any]]
) -> func.HttpResponse:
    """Execute an API operation with structured logging and safe error handling."""
    try:
        logger.info("telecom_api_request operation=%s", operation)
        subscriber = subscriber_for(req)
        payload = payload_factory()
        if isinstance(payload.get("data"), dict):
            payload["data"] = personalize(payload["data"], subscriber)
        return json_response(payload)
    except SubscriberRequestError as exc:
        return json_response(
            {
                "statusCode": str(exc.status_code),
                "statusMessage": "Bad Request" if exc.status_code == 400 else "Not Found",
                "supportMessage": str(exc),
            },
            exc.status_code,
        )
    except Exception:
        error_id = f"ERR-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        logger.exception(
            "telecom_api_error operation=%s error_id=%s", operation, error_id
        )
        return json_response(
            {
                "statusCode": "500",
                "statusMessage": "Internal Server Error",
                "supportMessage": "The request could not be processed.",
                "errorId": error_id,
            },
            500,
        )


def success_envelope(transaction_id: str, data: dict[str, Any]) -> dict[str, Any]:
    """Build the common successful response envelope."""
    return {
        "statusCode": "200",
        "statusMessage": "Success",
        "supportMessage": "Transaction processed successfully.",
        "transactionId": transaction_id,
        "data": data,
    }


@app.route(route="profile", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def profile(req: func.HttpRequest) -> func.HttpResponse:
    """Get a fictional Indian subscriber profile, plan, preferences, and flags.

    OpenAPI operation: getProfile. Returns HTTP 200 with ProfileResponse or
    HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getProfile", req,
        lambda: success_envelope(
            "PROF-20260806-000001",
            {
                "customerId": "CUST-IN-0001",
                "msisdn": "+919999900001",
                "customerType": "Individual",
                "subscriberType": "Prepaid",
                "status": "Active",
                "segment": "Retail",
                "telecomCircle": "Karnataka",
                "preferredLanguage": "en-IN",
                "activationDate": "2024-11-15",
                "plan": {
                    "planId": "PREPAID-299",
                    "planName": "Unlimited 5G Value 299",
                    "price": 299.0,
                    "currency": "INR",
                    "validityDays": 28,
                    "autoRenew": False,
                },
                "preferences": {
                    "smsNotifications": True,
                    "emailNotifications": False,
                    "marketingConsent": True,
                },
                "serviceFlags": {
                    "is5GEligible": True,
                    "internationalRoamingEnabled": False,
                    "dataOutOfBundleBarred": True,
                    "dndEnabled": False,
                },
            },
        ),
    )


@app.route(
    route="device-details", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def device_details(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional device, network, and SIM information for a subscriber.

    OpenAPI operation: getDeviceDetails. Returns HTTP 200 with
    DeviceDetailsResponse or HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getDeviceDetails", req,
        lambda: success_envelope(
            "DEV-20260806-000001",
            {
                "msisdn": "+919999900001",
                "device": {
                    "imei": "000000000000000",
                    "manufacturer": "Generic",
                    "model": "Android 5G Handset",
                    "deviceType": "Smartphone",
                    "operatingSystem": "Android",
                    "networkCapability": ["2G", "4G", "5G"],
                    "volteSupported": True,
                    "wifiCallingSupported": True,
                },
                "sim": {
                    "iccid": "8991000000000000001",
                    "imsi": "404000000000001",
                    "simType": "Nano SIM",
                    "simStatus": "Active",
                    "isEsim": False,
                    "homeNetworkCode": "404-00",
                    "activationDate": "2024-11-15",
                },
                "network": {
                    "currentTechnology": "5G NSA",
                    "roamingStatus": "Home Network",
                    "lastKnownCircle": "Karnataka",
                },
            },
        ),
    )


@app.route(route="balance", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def balance(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional prepaid wallet, data, voice, SMS, and add-on balances.

    OpenAPI operation: getBalance. Returns HTTP 200 with BalanceResponse or
    HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getBalance", req,
        lambda: success_envelope(
            "BAL-20260806-000001",
            {
                "subscriberType": "Prepaid",
                "asOf": "2026-08-06T10:30:00+05:30",
                "mainWallet": {
                    "balance": 146.75,
                    "currency": "INR",
                    "expiryDate": "2026-11-15",
                },
                "data": {
                    "totalMB": 5632,
                    "usedMB": 2147,
                    "remainingMB": 3485,
                    "dailyLimitMB": 2048,
                    "dailyRemainingMB": 1250,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "voice": {
                    "planType": "Unlimited",
                    "usedMinutes": 187,
                    "fairUsageMinutes": 3000,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "sms": {
                    "total": 100,
                    "used": 24,
                    "remaining": 76,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "addOnBalances": [
                    {
                        "id": "ADDON-5G-001",
                        "name": "Unlimited 5G Data",
                        "category": "Data",
                        "remaining": "Unlimited",
                        "expiryDate": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "ADDON-OTT-001",
                        "name": "Entertainment Data",
                        "category": "OTT",
                        "remaining": "1024 MB",
                        "expiryDate": "2026-08-10T23:59:59+05:30",
                    },
                ],
            },
        ),
    )


@app.route(
    route="purchase-history", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def purchase_history(req: func.HttpRequest) -> func.HttpResponse:
    """Get recent fictional recharge and add-on purchases in Indian rupees.

    OpenAPI operation: getPurchaseHistory. Returns HTTP 200 with
    PurchaseHistoryResponse or HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getPurchaseHistory", req,
        lambda: success_envelope(
            "HIST-20260806-000001",
            {
                "currency": "INR",
                "transactions": [
                    {
                        "id": "TXN-IN-1001",
                        "productId": "PLAN-299",
                        "product": "Unlimited 5G Value 299",
                        "category": "Prepaid Recharge",
                        "amount": 299.0,
                        "paymentMethod": "UPI",
                        "status": "Success",
                        "purchasedAt": "2026-07-24T18:42:10+05:30",
                        "validFrom": "2026-07-24T18:42:10+05:30",
                        "validUntil": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "TXN-IN-1002",
                        "productId": "DATA-19",
                        "product": "1 GB Data Booster",
                        "category": "Data Add-on",
                        "amount": 19.0,
                        "paymentMethod": "Main Balance",
                        "status": "Success",
                        "purchasedAt": "2026-08-01T09:15:30+05:30",
                        "validFrom": "2026-08-01T09:15:30+05:30",
                        "validUntil": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "TXN-IN-1003",
                        "productId": "OTT-49",
                        "product": "Entertainment Weekend Pack",
                        "category": "OTT Add-on",
                        "amount": 49.0,
                        "paymentMethod": "Wallet",
                        "status": "Success",
                        "purchasedAt": "2026-08-02T20:05:12+05:30",
                        "validFrom": "2026-08-02T20:05:12+05:30",
                        "validUntil": "2026-08-09T23:59:59+05:30",
                    },
                ],
            },
        ),
    )


@app.route(route="offers", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def offers(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional personalized prepaid, data, voice, and OTT offers.

    OpenAPI operation: getOffers. Returns HTTP 200 with OffersResponse or HTTP
    500 with ErrorResponse.
    """
    return api_handler(
        "getOffers", req,
        lambda: success_envelope(
            "OFF-20260806-000001",
            {
                "currency": "INR",
                "offers": [
                    {
                        "id": "OFFER-IN-239",
                        "name": "Unlimited Value 239",
                        "description": "1.5 GB/day, unlimited voice and 100 SMS/day.",
                        "category": "Prepaid Recharge",
                        "price": 239.0,
                        "validity": {"amount": 24, "unit": "Days"},
                        "benefits": ["1.5 GB data/day", "Unlimited voice", "100 SMS/day"],
                        "isPersonalized": True,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-61",
                        "name": "6 GB Data Booster",
                        "description": "Extra high-speed data valid with the active base plan.",
                        "category": "Data Add-on",
                        "price": 61.0,
                        "validity": {"amount": 28, "unit": "Days"},
                        "benefits": ["6 GB high-speed data"],
                        "isPersonalized": False,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-25",
                        "name": "Weekend Entertainment Pack",
                        "description": "1 GB data for supported video and music services.",
                        "category": "OTT",
                        "price": 25.0,
                        "validity": {"amount": 3, "unit": "Days"},
                        "benefits": ["1 GB entertainment data", "Weekend validity"],
                        "isPersonalized": True,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-129",
                        "name": "International Roaming Starter",
                        "description": "Starter roaming allowance for selected destinations.",
                        "category": "International Roaming",
                        "price": 129.0,
                        "validity": {"amount": 1, "unit": "Day"},
                        "benefits": ["100 MB data", "10 voice minutes"],
                        "isPersonalized": False,
                        "isEligible": True,
                    },
                ],
            },
        ),
    )


# ============================================================================
# GAF-POC -- Smart Order Helper + Product & Warranty Advisor + Contractors
# ============================================================================
# No auth (ANONYMOUS, matching the telecom section above -- same
# no-security-needed demo). Every route is a read-only lookup over the
# synthetic dataset in ./gaf_data, served through the shared GafCatalog
# (byte-identical to the backend's app/services/gaf_catalog.py, so the
# app's "local" mode and this "live" mode return the same envelopes).
# Knowledge documents return their FULL TEXT and passages -- the calling
# model cannot follow links, so nothing here is a URL to somewhere else.

from pathlib import Path

from gaf_catalog import CatalogError, GafCatalog

GAF = GafCatalog(Path(__file__).resolve().parent / "gaf_data")


def gaf_handler(operation: str, payload_factory: Callable[[], dict[str, Any]]) -> func.HttpResponse:
    """Same structured try/except shape as api_handler() above, without the
    subscriber resolution + personalize() step -- these routes are plain
    lookups, not "data for the currently authenticated caller"."""
    try:
        logger.info("gaf_api_request operation=%s", operation)
        return json_response(success_envelope(f"GAF-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}", payload_factory()))
    except CatalogError as exc:
        return json_response(
            {
                "statusCode": str(exc.status_code),
                "statusMessage": "Bad Request" if exc.status_code == 400 else "Not Found",
                "supportMessage": str(exc),
            },
            exc.status_code,
        )
    except Exception:
        error_id = f"ERR-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        logger.exception("gaf_api_error operation=%s error_id=%s", operation, error_id)
        return json_response(
            {
                "statusCode": "500",
                "statusMessage": "Internal Server Error",
                "supportMessage": "The request could not be processed.",
                "errorId": error_id,
            },
            500,
        )


def _p(req: func.HttpRequest, name: str) -> str | None:
    value = (req.params.get(name) or "").strip()
    return value or None


def _num(req: func.HttpRequest, name: str, default: float) -> float:
    try:
        return float(req.params.get(name) or default)
    except ValueError:
        return default


@app.route(route="gaf/products", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_products(req: func.HttpRequest) -> func.HttpResponse:
    """Product catalogue with unit prices, coverage, colour swatches, badges
    and recommended add-ons. ?sku=... for one product; ?family=... / ?type=...
    to filter; otherwise the active catalogue.  OpenAPI: gafGetProducts."""
    return gaf_handler("gafGetProducts", lambda: GAF.products(sku=_p(req, "sku"), family=_p(req, "family"), product_type=_p(req, "type")))


@app.route(route="gaf/inventory", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_inventory(req: func.HttpRequest) -> func.HttpResponse:
    """Per-warehouse stock (144 rows, 6 DCs). ?sku=... and/or ?warehouseId=...
    (at least one).  OpenAPI: gafGetInventory."""
    return gaf_handler("gafGetInventory", lambda: GAF.inventory(sku=_p(req, "sku"), warehouse_id=_p(req, "warehouseId")))


@app.route(route="gaf/customers", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_customers(req: func.HttpRequest) -> func.HttpResponse:
    """Customer accounts. ?accountId=..., ?name=... (name/trade name/alias,
    exact match wins over partial), ?zip=..., ?repId=...  OpenAPI: gafGetCustomers."""
    return gaf_handler("gafGetCustomers", lambda: GAF.customers(account_id=_p(req, "accountId"), name=_p(req, "name"), zip_code=_p(req, "zip"), rep_id=_p(req, "repId")))


@app.route(route="gaf/orders", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_orders(req: func.HttpRequest) -> func.HttpResponse:
    """Orders with priced lines. Filters: ?accountId, ?sku, ?orderId, ?repId,
    ?status.  OpenAPI: gafGetOrders."""
    return gaf_handler("gafGetOrders", lambda: GAF.orders(account_id=_p(req, "accountId"), sku=_p(req, "sku"), order_id=_p(req, "orderId"), rep_id=_p(req, "repId"), status=_p(req, "status")))


@app.route(route="gaf/documents", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_documents(req: func.HttpRequest) -> func.HttpResponse:
    """Approved knowledge documents WITH full content and citable passages.
    ?docId=... for one; ?content=false for metadata only. Each entry gets a
    computed status (active/expired) against today's date.  OpenAPI: gafGetDocuments."""
    include = (req.params.get("content") or "true").lower() != "false"
    return gaf_handler("gafGetDocuments", lambda: GAF.documents(doc_id=_p(req, "docId"), include_content=include))


@app.route(route="gaf/kb-passages", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_kb_passages(req: func.HttpRequest) -> func.HttpResponse:
    """Citable passages from active documents. ?docId, ?intent, ?q=<keywords>
    (keyword-scored).  OpenAPI: gafGetKbPassages."""
    return gaf_handler("gafGetKbPassages", lambda: GAF.kb_passages(doc_id=_p(req, "docId"), intent=_p(req, "intent"), query=_p(req, "q")))


@app.route(route="gaf/product-approval", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_product_approval(req: func.HttpRequest) -> func.HttpResponse:
    """Florida / Miami-Dade approval registry. ?product=... required.
    OpenAPI: gafGetProductApproval."""
    return gaf_handler("gafGetProductApproval", lambda: GAF.product_approval(_p(req, "product") or ""))


@app.route(route="gaf/warranty-rules", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_warranty_rules(req: func.HttpRequest) -> func.HttpResponse:
    """Warranty tier requirements. ?tier=... for one tier.  OpenAPI: gafGetWarrantyRules."""
    return gaf_handler("gafGetWarrantyRules", lambda: GAF.warranty_rules(tier=_p(req, "tier")))


@app.route(route="gaf/escalation-rules", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_escalation_rules(req: func.HttpRequest) -> func.HttpResponse:
    """The escalation-rules table, always in full.  OpenAPI: gafGetEscalationRules."""
    return gaf_handler("gafGetEscalationRules", GAF.escalation_rules)


@app.route(route="gaf/warehouses", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_warehouses(req: func.HttpRequest) -> func.HttpResponse:
    """Distribution centres. ?warehouseId=... for one.  OpenAPI: gafGetWarehouses."""
    return gaf_handler("gafGetWarehouses", lambda: GAF.warehouses(warehouse_id=_p(req, "warehouseId")))


@app.route(route="gaf/add-on-rules", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_add_on_rules(req: func.HttpRequest) -> func.HttpResponse:
    """Add-on recommendation rules with parsed quantity logic.  OpenAPI: gafGetAddOnRules."""
    return gaf_handler("gafGetAddOnRules", GAF.add_on_rules)


@app.route(route="gaf/discounts", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_discounts(req: func.HttpRequest) -> func.HttpResponse:
    """Automatic discounts (volume, seasonal, bundle, account) active on
    ?date=YYYY-MM-DD (default today).  OpenAPI: gafGetDiscounts."""
    return gaf_handler("gafGetDiscounts", lambda: GAF.discounts(on_date=_p(req, "date")))


@app.route(route="gaf/contractors", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_contractors(req: func.HttpRequest) -> func.HttpResponse:
    """GAF-certified contractors near ?zip=... or ?city=..., within ?radius
    miles (default 25), up to ?limit (default 10), optional ?minTier=
    certified|certified_plus|master_elite|presidents_club.  OpenAPI: gafGetContractors."""
    return gaf_handler("gafGetContractors", lambda: GAF.contractors(
        zip_code=_p(req, "zip"), city=_p(req, "city"), radius_miles=_num(req, "radius", 25.0),
        limit=int(_num(req, "limit", 10)), min_tier=_p(req, "minTier")))


@app.route(route="gaf/zips", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_zips(req: func.HttpRequest) -> func.HttpResponse:
    """ZIP -> city/county/region/HVHZ context. ?zip=... required.  OpenAPI: gafGetZip."""
    return gaf_handler("gafGetZip", lambda: GAF.zip_lookup(_p(req, "zip") or ""))


@app.route(route="gaf/counties", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_counties(req: func.HttpRequest) -> func.HttpResponse:
    """County regimes (HVHZ / non-HVHZ / non-Florida). ?regionId=... for one.
    OpenAPI: gafGetCounties."""
    return gaf_handler("gafGetCounties", lambda: GAF.counties(region_id=_p(req, "regionId")))


@app.route(route="gaf/sales-reps", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_sales_reps(req: func.HttpRequest) -> func.HttpResponse:
    """Sales reps with territories, commission rates and assigned accounts.
    ?repId=... for one.  OpenAPI: gafGetSalesReps."""
    return gaf_handler("gafGetSalesReps", lambda: GAF.sales_reps(rep_id=_p(req, "repId")))


@app.route(route="gaf/emails", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_emails(req: func.HttpRequest) -> func.HttpResponse:
    """Synthetic customer inbox for the email agent. ?emailId, ?accountId, ?repId.
    OpenAPI: gafGetEmails."""
    return gaf_handler("gafGetEmails", lambda: GAF.emails(email_id=_p(req, "emailId"), account_id=_p(req, "accountId"), rep_id=_p(req, "repId")))


@app.route(route="gaf/use-cases", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_use_cases(req: func.HttpRequest) -> func.HttpResponse:
    """Demo use cases plus the workbook's order/advisor scenarios.  OpenAPI: gafGetUseCases."""
    return gaf_handler("gafGetUseCases", GAF.use_cases)
