"""Telecom-POC + GAF-POC mock APIs, both on the Azure Functions v2
programming model, in one Function App (Consumption plan bills per
execution regardless of how many apps host the routes, and a demo with no
security-isolation need gets nothing from a second Storage
Account/Application Insights pair -- so this is one app, two unrelated
route groups).

All subscriber/customer identifiers and commercial data in this module are
fictional. The response envelopes are intentionally suitable for future
replacement by Azure AI Foundry tools, CRM services, billing systems, and
product catalogues.

The GAF section below (routes under /api/gaf/...) is deliberately
info-only: eight read-only lookups covering both agents from the GAF
Prototype Build Brief --

  Smart Order Helper:      products, inventory, customers, orders
  Product & Warranty Advisor: documents, product-approval, warranty-rules,
                               escalation-rules

Order-building, confirmation, and escalation *decisions* are orchestration
logic that belongs in the calling app (same separation telecom-assistant
already keeps: this Function App is a data source, never the thing that
decides or acts). Sample data is transcribed directly from the brief's own
Data Sets A-I -- not invented -- so it matches gaf_demo's local JSON/docs
where those already exist.
"""

import json
import logging
import re
from datetime import UTC, datetime
from typing import Any, Callable

import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)
logger = logging.getLogger(__name__)


class SubscriberRequestError(ValueError):
    """A client error caused by missing or unsupported subscriber context."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


def json_response(payload: dict[str, Any], status_code: int = 200) -> func.HttpResponse:
    """Return a consistently encoded JSON response."""
    return func.HttpResponse(
        json.dumps(payload, ensure_ascii=False),
        status_code=status_code,
        mimetype="application/json",
    )


SUBSCRIBERS = {
    f"+9199999000{i:02d}": {
        "customerId": f"CUST-IN-{i:04d}",
        "msisdn": f"+9199999000{i:02d}",
        "circle": ["Karnataka", "Maharashtra", "Delhi", "Tamil Nadu", "Gujarat",
                   "West Bengal", "Telangana", "Kerala", "Rajasthan", "Uttar Pradesh"][i - 1],
        "subscriberType": "Prepaid" if i % 2 else "Postpaid",
        "planPrice": 199.0 + i * 20,
        "balance": 50.0 + i * 17.5,
        "language": ["en-IN", "hi-IN", "mr-IN", "ta-IN", "gu-IN",
                     "bn-IN", "te-IN", "ml-IN", "hi-IN", "hi-IN"][i - 1],
        "device": [
            ("Samsung", "Galaxy A54 5G"), ("Apple", "iPhone 15"),
            ("OnePlus", "Nord CE 4"), ("Xiaomi", "Redmi Note 13 Pro"),
            ("Motorola", "Edge 50 Fusion"), ("Nothing", "Phone (2a)"),
            ("Google", "Pixel 8a"), ("Vivo", "V30 5G"),
            ("Oppo", "Reno 11 5G"), ("Realme", "12 Pro 5G"),
        ][i - 1],
    }
    for i in range(1, 11)
}


def subscriber_for(req: func.HttpRequest) -> dict[str, Any]:
    """Require and resolve one of the ten configured mock subscribers."""
    requested = req.params.get("msisdn") or req.params.get("mobileNumber")
    if not requested or not requested.strip():
        raise SubscriberRequestError(
            "The mobileNumber query parameter is required.", 400
        )

    # A literal '+' in a URL query may be decoded as a space. Normalizing to
    # digits supports both '?mobileNumber=+91...' and the encoded '%2B91...'.
    digits = re.sub(r"\D", "", requested)
    number = f"+{digits}"
    if number not in SUBSCRIBERS:
        raise SubscriberRequestError(
            "Unknown mobileNumber. Use +919999900001 through +919999900010.",
            404,
        )
    return SUBSCRIBERS[number]


def personalize(data: dict[str, Any], subscriber: dict[str, Any]) -> dict[str, Any]:
    """Apply deterministic per-subscriber differences while retaining API contracts."""
    index = int(subscriber["customerId"][-4:])
    data = json.loads(json.dumps(data))
    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key == "msisdn": value[key] = subscriber["msisdn"]
                elif key == "customerId": value[key] = subscriber["customerId"]
                elif key == "telecomCircle" or key == "lastKnownCircle": value[key] = subscriber["circle"]
                elif key == "subscriberType": value[key] = subscriber["subscriberType"]
                elif key == "preferredLanguage": value[key] = subscriber["language"]
                elif key == "manufacturer": value[key] = subscriber["device"][0]
                elif key == "model": value[key] = subscriber["device"][1]
                elif key == "imei": value[key] = f"350000000000{index:03d}"
                elif key == "iccid": value[key] = f"8991000000000000{index:04d}"
                elif key == "imsi": value[key] = f"40400000000{index:04d}"
                elif key in {"id", "productId"} and isinstance(item, str): value[key] = f"{item}-{index:02d}"
                elif key == "price" and isinstance(item, (int, float)): value[key] = subscriber["planPrice"] if "planId" in value else item + index * 3
                elif key == "amount" and isinstance(item, (int, float)): value[key] = item + index * 2
                elif key == "balance" and isinstance(item, (int, float)): value[key] = subscriber["balance"]
                elif key in {"usedMB", "usedMinutes", "used", "balance"} and isinstance(item, (int, float)): value[key] = item + index * 10
                else: visit(item)
        elif isinstance(value, list):
            for item in value: visit(item)
    visit(data)
    return data


def api_handler(
    operation: str, req: func.HttpRequest, payload_factory: Callable[[], dict[str, Any]]
) -> func.HttpResponse:
    """Execute an API operation with structured logging and safe error handling."""
    try:
        logger.info("telecom_api_request operation=%s", operation)
        subscriber = subscriber_for(req)
        payload = payload_factory()
        if isinstance(payload.get("data"), dict):
            payload["data"] = personalize(payload["data"], subscriber)
        return json_response(payload)
    except SubscriberRequestError as exc:
        return json_response(
            {
                "statusCode": str(exc.status_code),
                "statusMessage": "Bad Request" if exc.status_code == 400 else "Not Found",
                "supportMessage": str(exc),
            },
            exc.status_code,
        )
    except Exception:
        error_id = f"ERR-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        logger.exception(
            "telecom_api_error operation=%s error_id=%s", operation, error_id
        )
        return json_response(
            {
                "statusCode": "500",
                "statusMessage": "Internal Server Error",
                "supportMessage": "The request could not be processed.",
                "errorId": error_id,
            },
            500,
        )


def success_envelope(transaction_id: str, data: dict[str, Any]) -> dict[str, Any]:
    """Build the common successful response envelope."""
    return {
        "statusCode": "200",
        "statusMessage": "Success",
        "supportMessage": "Transaction processed successfully.",
        "transactionId": transaction_id,
        "data": data,
    }


@app.route(route="profile", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def profile(req: func.HttpRequest) -> func.HttpResponse:
    """Get a fictional Indian subscriber profile, plan, preferences, and flags.

    OpenAPI operation: getProfile. Returns HTTP 200 with ProfileResponse or
    HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getProfile", req,
        lambda: success_envelope(
            "PROF-20260806-000001",
            {
                "customerId": "CUST-IN-0001",
                "msisdn": "+919999900001",
                "customerType": "Individual",
                "subscriberType": "Prepaid",
                "status": "Active",
                "segment": "Retail",
                "telecomCircle": "Karnataka",
                "preferredLanguage": "en-IN",
                "activationDate": "2024-11-15",
                "plan": {
                    "planId": "PREPAID-299",
                    "planName": "Unlimited 5G Value 299",
                    "price": 299.0,
                    "currency": "INR",
                    "validityDays": 28,
                    "autoRenew": False,
                },
                "preferences": {
                    "smsNotifications": True,
                    "emailNotifications": False,
                    "marketingConsent": True,
                },
                "serviceFlags": {
                    "is5GEligible": True,
                    "internationalRoamingEnabled": False,
                    "dataOutOfBundleBarred": True,
                    "dndEnabled": False,
                },
            },
        ),
    )


@app.route(
    route="device-details", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def device_details(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional device, network, and SIM information for a subscriber.

    OpenAPI operation: getDeviceDetails. Returns HTTP 200 with
    DeviceDetailsResponse or HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getDeviceDetails", req,
        lambda: success_envelope(
            "DEV-20260806-000001",
            {
                "msisdn": "+919999900001",
                "device": {
                    "imei": "000000000000000",
                    "manufacturer": "Generic",
                    "model": "Android 5G Handset",
                    "deviceType": "Smartphone",
                    "operatingSystem": "Android",
                    "networkCapability": ["2G", "4G", "5G"],
                    "volteSupported": True,
                    "wifiCallingSupported": True,
                },
                "sim": {
                    "iccid": "8991000000000000001",
                    "imsi": "404000000000001",
                    "simType": "Nano SIM",
                    "simStatus": "Active",
                    "isEsim": False,
                    "homeNetworkCode": "404-00",
                    "activationDate": "2024-11-15",
                },
                "network": {
                    "currentTechnology": "5G NSA",
                    "roamingStatus": "Home Network",
                    "lastKnownCircle": "Karnataka",
                },
            },
        ),
    )


@app.route(route="balance", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def balance(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional prepaid wallet, data, voice, SMS, and add-on balances.

    OpenAPI operation: getBalance. Returns HTTP 200 with BalanceResponse or
    HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getBalance", req,
        lambda: success_envelope(
            "BAL-20260806-000001",
            {
                "subscriberType": "Prepaid",
                "asOf": "2026-08-06T10:30:00+05:30",
                "mainWallet": {
                    "balance": 146.75,
                    "currency": "INR",
                    "expiryDate": "2026-11-15",
                },
                "data": {
                    "totalMB": 5632,
                    "usedMB": 2147,
                    "remainingMB": 3485,
                    "dailyLimitMB": 2048,
                    "dailyRemainingMB": 1250,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "voice": {
                    "planType": "Unlimited",
                    "usedMinutes": 187,
                    "fairUsageMinutes": 3000,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "sms": {
                    "total": 100,
                    "used": 24,
                    "remaining": 76,
                    "expiryDate": "2026-08-20T23:59:59+05:30",
                },
                "addOnBalances": [
                    {
                        "id": "ADDON-5G-001",
                        "name": "Unlimited 5G Data",
                        "category": "Data",
                        "remaining": "Unlimited",
                        "expiryDate": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "ADDON-OTT-001",
                        "name": "Entertainment Data",
                        "category": "OTT",
                        "remaining": "1024 MB",
                        "expiryDate": "2026-08-10T23:59:59+05:30",
                    },
                ],
            },
        ),
    )


@app.route(
    route="purchase-history", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS
)
def purchase_history(req: func.HttpRequest) -> func.HttpResponse:
    """Get recent fictional recharge and add-on purchases in Indian rupees.

    OpenAPI operation: getPurchaseHistory. Returns HTTP 200 with
    PurchaseHistoryResponse or HTTP 500 with ErrorResponse.
    """
    return api_handler(
        "getPurchaseHistory", req,
        lambda: success_envelope(
            "HIST-20260806-000001",
            {
                "currency": "INR",
                "transactions": [
                    {
                        "id": "TXN-IN-1001",
                        "productId": "PLAN-299",
                        "product": "Unlimited 5G Value 299",
                        "category": "Prepaid Recharge",
                        "amount": 299.0,
                        "paymentMethod": "UPI",
                        "status": "Success",
                        "purchasedAt": "2026-07-24T18:42:10+05:30",
                        "validFrom": "2026-07-24T18:42:10+05:30",
                        "validUntil": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "TXN-IN-1002",
                        "productId": "DATA-19",
                        "product": "1 GB Data Booster",
                        "category": "Data Add-on",
                        "amount": 19.0,
                        "paymentMethod": "Main Balance",
                        "status": "Success",
                        "purchasedAt": "2026-08-01T09:15:30+05:30",
                        "validFrom": "2026-08-01T09:15:30+05:30",
                        "validUntil": "2026-08-20T23:59:59+05:30",
                    },
                    {
                        "id": "TXN-IN-1003",
                        "productId": "OTT-49",
                        "product": "Entertainment Weekend Pack",
                        "category": "OTT Add-on",
                        "amount": 49.0,
                        "paymentMethod": "Wallet",
                        "status": "Success",
                        "purchasedAt": "2026-08-02T20:05:12+05:30",
                        "validFrom": "2026-08-02T20:05:12+05:30",
                        "validUntil": "2026-08-09T23:59:59+05:30",
                    },
                ],
            },
        ),
    )


@app.route(route="offers", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def offers(req: func.HttpRequest) -> func.HttpResponse:
    """Get fictional personalized prepaid, data, voice, and OTT offers.

    OpenAPI operation: getOffers. Returns HTTP 200 with OffersResponse or HTTP
    500 with ErrorResponse.
    """
    return api_handler(
        "getOffers", req,
        lambda: success_envelope(
            "OFF-20260806-000001",
            {
                "currency": "INR",
                "offers": [
                    {
                        "id": "OFFER-IN-239",
                        "name": "Unlimited Value 239",
                        "description": "1.5 GB/day, unlimited voice and 100 SMS/day.",
                        "category": "Prepaid Recharge",
                        "price": 239.0,
                        "validity": {"amount": 24, "unit": "Days"},
                        "benefits": ["1.5 GB data/day", "Unlimited voice", "100 SMS/day"],
                        "isPersonalized": True,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-61",
                        "name": "6 GB Data Booster",
                        "description": "Extra high-speed data valid with the active base plan.",
                        "category": "Data Add-on",
                        "price": 61.0,
                        "validity": {"amount": 28, "unit": "Days"},
                        "benefits": ["6 GB high-speed data"],
                        "isPersonalized": False,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-25",
                        "name": "Weekend Entertainment Pack",
                        "description": "1 GB data for supported video and music services.",
                        "category": "OTT",
                        "price": 25.0,
                        "validity": {"amount": 3, "unit": "Days"},
                        "benefits": ["1 GB entertainment data", "Weekend validity"],
                        "isPersonalized": True,
                        "isEligible": True,
                    },
                    {
                        "id": "OFFER-IN-129",
                        "name": "International Roaming Starter",
                        "description": "Starter roaming allowance for selected destinations.",
                        "category": "International Roaming",
                        "price": 129.0,
                        "validity": {"amount": 1, "unit": "Day"},
                        "benefits": ["100 MB data", "10 voice minutes"],
                        "isPersonalized": False,
                        "isEligible": True,
                    },
                ],
            },
        ),
    )


# ============================================================================
# GAF-POC — Smart Order Helper + Product & Warranty Advisor (info-only)
# ============================================================================
# No auth (ANONYMOUS, matching the telecom section above -- same
# no-security-needed demo). No "current caller" concept like mobileNumber
# above: every route here takes an explicit id (accountId, sku, docId,
# product, tier) as a query parameter, defaulting to "return everything"
# when omitted, since these are lookup tables, not a per-caller identity.


class GafLookupError(ValueError):
    """A client error: an unknown id, or a required parameter that's missing."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


def gaf_handler(operation: str, payload_factory: Callable[[], dict[str, Any]]) -> func.HttpResponse:
    """Same structured try/except shape as api_handler() above, without the
    subscriber resolution + personalize() step -- these routes are plain
    lookups, not "data for the currently authenticated caller"."""
    try:
        logger.info("gaf_api_request operation=%s", operation)
        return json_response(success_envelope(f"GAF-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}", payload_factory()))
    except GafLookupError as exc:
        return json_response(
            {
                "statusCode": str(exc.status_code),
                "statusMessage": "Bad Request" if exc.status_code == 400 else "Not Found",
                "supportMessage": str(exc),
            },
            exc.status_code,
        )
    except Exception:
        error_id = f"ERR-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
        logger.exception("gaf_api_error operation=%s error_id=%s", operation, error_id)
        return json_response(
            {
                "statusCode": "500",
                "statusMessage": "Internal Server Error",
                "supportMessage": "The request could not be processed.",
                "errorId": error_id,
            },
            500,
        )


# ---- Data Set A + B: Product Catalogue + Add-on Rules (merged, same
# consolidation gaf_demo/data/products.json already uses) ----
GAF_PRODUCTS = {
    "TL-HDZ-CHAR": {
        "sku": "TL-HDZ-CHAR", "productName": "Timberline HDZ Shingles", "productFamily": "Timberline HDZ",
        "colour": "Charcoal", "soldIn": "Square", "bundlesPerSquare": 3, "productType": "Main shingle",
        "recommendedAddOns": ["PRO-START", "SEAL-RIDGE", "TIGER-PAW", "COBRA-VENT"],
        "addOnReason": "These four categories complete the roof system and unlock the strongest wind warranty.",
        "largeOrderDeliveryCheck": {"thresholdSquares": 30, "action": "Confirm delivery method (job-site vs warehouse)."},
    },
    "TL-HDZ-WEA": {
        "sku": "TL-HDZ-WEA", "productName": "Timberline HDZ Shingles", "productFamily": "Timberline HDZ",
        "colour": "Weathered Wood", "soldIn": "Square", "bundlesPerSquare": 3, "productType": "Main shingle",
        "recommendedAddOns": ["PRO-START", "SEAL-RIDGE", "TIGER-PAW", "COBRA-VENT"],
        "addOnReason": "These four categories complete the roof system and unlock the strongest wind warranty.",
        "largeOrderDeliveryCheck": {"thresholdSquares": 30, "action": "Confirm delivery method (job-site vs warehouse)."},
    },
    "PRO-START": {
        "sku": "PRO-START", "productName": "Pro-Start Starter Strip", "productFamily": None,
        "colour": "N/A", "soldIn": "Bundle", "bundlesPerSquare": 1, "productType": "Starter strip",
    },
    "SEAL-RIDGE": {
        "sku": "SEAL-RIDGE", "productName": "Seal-A-Ridge Ridge Cap", "productFamily": None,
        "colour": "Charcoal", "soldIn": "Bundle", "bundlesPerSquare": 1, "productType": "Ridge cap",
    },
    "TIGER-PAW": {
        "sku": "TIGER-PAW", "productName": "Tiger Paw Roof Deck Protection", "productFamily": None,
        "colour": "N/A", "soldIn": "Roll", "bundlesPerSquare": 1, "productType": "Underlayment",
    },
    "COBRA-VENT": {
        "sku": "COBRA-VENT", "productName": "Cobra Ventilation", "productFamily": None,
        "colour": "N/A", "soldIn": "Piece", "bundlesPerSquare": 1, "productType": "Ventilation",
    },
}

# ---- Data Set C: Inventory ----
GAF_INVENTORY = {
    "TL-HDZ-CHAR": [{"sku": "TL-HDZ-CHAR", "warehouse": "Tampa DC", "quantityAvailable": 220, "unit": "squares", "restockDate": None}],
    "TL-HDZ-WEA": [{"sku": "TL-HDZ-WEA", "warehouse": "Tampa DC", "quantityAvailable": 12, "unit": "squares", "restockDate": "2026-09-18"}],
    "PRO-START": [{"sku": "PRO-START", "warehouse": "Tampa DC", "quantityAvailable": 500, "unit": "bundles", "restockDate": None}],
    "SEAL-RIDGE": [{"sku": "SEAL-RIDGE", "warehouse": "Tampa DC", "quantityAvailable": 40, "unit": "bundles", "restockDate": "2026-09-20"}],
    "COBRA-VENT": [{"sku": "COBRA-VENT", "warehouse": "Atlanta DC", "quantityAvailable": 300, "unit": "pieces", "restockDate": None}],
}

# ---- Data Set D: Customer Accounts ----
GAF_CUSTOMERS = {
    "ACC-1001": {
        "accountId": "ACC-1001", "customerName": "Sunshine Roofing Supply", "aliases": ["Sunshine Roofing"],
        "defaultShipToCity": "Tampa, FL", "creditStatus": "Good standing", "creditLimitUsedPercent": 40, "creditHold": False,
    },
    "ACC-1002": {
        "accountId": "ACC-1002", "customerName": "Gulf Coast Distributors", "aliases": [],
        "defaultShipToCity": "Naples, FL", "creditStatus": "CREDIT HOLD", "creditLimitUsedPercent": 105, "creditHold": True,
    },
    "ACC-1003": {
        "accountId": "ACC-1003", "customerName": "Bayline Contractors", "aliases": [],
        "defaultShipToCity": "Miami, FL", "creditStatus": "Good standing", "creditLimitUsedPercent": 60, "creditHold": False,
    },
}

# ---- Data Set E: Recent Orders (duplicate detection) ----
GAF_ORDERS = [
    {"orderId": "ORD-77012", "accountId": "ACC-1001", "sku": "TL-HDZ-CHAR", "quantity": 60, "unit": "squares", "orderDate": "2026-09-10", "deliveryDate": "2026-09-16"},
    {"orderId": "ORD-77013", "accountId": "ACC-1003", "sku": "COBRA-VENT", "quantity": 50, "unit": "pieces", "orderDate": "2026-09-10", "deliveryDate": "2026-09-15"},
]

# ---- Data Set F: Approved Knowledge Documents ----
GAF_DOCUMENTS = {
    "DOC-101": {"docId": "DOC-101", "title": "Timberline HDZ Data Sheet", "topic": "Product specs & colours", "version": "4.2", "validUntil": "2026-12-31"},
    "DOC-102": {"docId": "DOC-102", "title": "WindProven Warranty Terms", "topic": "Warranty rules & accessories", "version": "3.0", "validUntil": "2027-06-30"},
    "DOC-103": {"docId": "DOC-103", "title": "Florida Install Guide", "topic": "Nailing & underlayment", "version": "2.1", "validUntil": "2026-12-31"},
    "DOC-104": {"docId": "DOC-104", "title": "StainGuard Algae Warranty", "topic": "Discolouration coverage", "version": "1.5", "validUntil": "2027-03-31"},
}

# ---- Data Set G: Product Approval Registry ----
GAF_PRODUCT_APPROVAL = {
    "Timberline HDZ": {
        "product": "Timberline HDZ", "floridaApproval": "FL-16254.3", "miamiDadeNoa": "NOA 22-0518.09",
        "standardWindTier": "Up to 130 mph", "windProvenTier": "No maximum (system required)",
    },
}

# ---- Data Set H: Warranty Requirement Rules ----
GAF_WARRANTY_RULES = {
    "Standard Limited": {
        "tier": "Standard Limited", "installMethod": "Standard nailing",
        "accessoriesRequired": ["Shingle only"], "windCoverage": "Up to 130 mph",
    },
    "WindProven": {
        "tier": "WindProven", "installMethod": "LayerLock method (special nail zone)",
        "accessoriesRequired": ["Leak barrier", "Roof deck protection", "Starter strip", "Ridge cap"],
        "windCoverage": "No maximum wind speed",
    },
}

# ---- Data Set I: Escalation Rules ----
GAF_ESCALATION_RULES = [
    {"topic": "General product facts, warranty tiers, which accessories are needed", "action": "Answer (with source)", "sendTo": None},
    {"topic": "Exact nailing pattern for a specific building; design wind speed; HVHZ specifics", "action": "Do not answer; build a case", "sendTo": "Technical Services"},
    {"topic": "Leak, safety, or a possible product defect", "action": "Do not answer; flag urgent", "sendTo": "Technical Services (urgent)"},
    {"topic": "Anything with no approved source", "action": 'Say "no approved source available"', "sendTo": None},
]


@app.route(route="gaf/products", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_products(req: func.HttpRequest) -> func.HttpResponse:
    """Product catalogue + add-on rules (Data Sets A & B). ?sku=... for one
    product, otherwise the full catalogue.

    OpenAPI operation: gafGetProducts.
    """
    sku = (req.params.get("sku") or "").strip().upper()

    def build() -> dict[str, Any]:
        if not sku:
            return {"products": list(GAF_PRODUCTS.values())}
        product = GAF_PRODUCTS.get(sku)
        if product is None:
            raise GafLookupError(f"Unknown sku. Known SKUs: {', '.join(GAF_PRODUCTS)}.", 404)
        return {"products": [product]}

    return gaf_handler("gafGetProducts", build)


@app.route(route="gaf/inventory", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_inventory(req: func.HttpRequest) -> func.HttpResponse:
    """Per-warehouse stock (Data Set C). ?sku=... required.

    OpenAPI operation: gafGetInventory.
    """
    sku = (req.params.get("sku") or "").strip().upper()

    def build() -> dict[str, Any]:
        if not sku:
            raise GafLookupError("The sku query parameter is required.", 400)
        records = GAF_INVENTORY.get(sku)
        if records is None:
            raise GafLookupError(f"No inventory data for sku '{sku}'.", 404)
        return {"inventory": records}

    return gaf_handler("gafGetInventory", build)


@app.route(route="gaf/customers", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_customers(req: func.HttpRequest) -> func.HttpResponse:
    """Customer accounts (Data Set D). ?accountId=... for one record, or
    ?name=... to resolve a customer name/alias (case-insensitive, matching
    the Order Reader's "customer name or alias" requirement in the brief).

    OpenAPI operation: gafGetCustomers.
    """
    account_id = (req.params.get("accountId") or "").strip().upper()
    name = (req.params.get("name") or "").strip().lower()

    def build() -> dict[str, Any]:
        if account_id:
            customer = GAF_CUSTOMERS.get(account_id)
            if customer is None:
                raise GafLookupError(f"Unknown accountId. Known accounts: {', '.join(GAF_CUSTOMERS)}.", 404)
            return {"customers": [customer]}
        if name:
            matches = [
                c for c in GAF_CUSTOMERS.values()
                if name in c["customerName"].lower() or any(name in a.lower() for a in c["aliases"])
            ]
            if not matches:
                raise GafLookupError(f"No customer name or alias matches '{name}'.", 404)
            return {"customers": matches}
        return {"customers": list(GAF_CUSTOMERS.values())}

    return gaf_handler("gafGetCustomers", build)


@app.route(route="gaf/orders", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_orders(req: func.HttpRequest) -> func.HttpResponse:
    """Recent orders, for duplicate-order detection (Data Set E). Optional
    ?accountId=... and/or ?sku=... filters; both, either, or neither.

    OpenAPI operation: gafGetOrders.
    """
    account_id = (req.params.get("accountId") or "").strip().upper()
    sku = (req.params.get("sku") or "").strip().upper()

    def build() -> dict[str, Any]:
        matches = GAF_ORDERS
        if account_id:
            matches = [o for o in matches if o["accountId"] == account_id]
        if sku:
            matches = [o for o in matches if o["sku"] == sku]
        return {"orders": matches}

    return gaf_handler("gafGetOrders", build)


@app.route(route="gaf/documents", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_documents(req: func.HttpRequest) -> func.HttpResponse:
    """Approved knowledge document registry (Data Set F) -- metadata only,
    not document content (that lives in Foundry File Search). Each entry
    gets a computed status (active/expired) against today's date, so the
    Warranty Advisor can check freshness before trusting a RAG hit, per the
    brief's "using only the latest, non-expired versions" rule.
    ?docId=... for one document, otherwise the full registry.

    OpenAPI operation: gafGetDocuments.
    """
    doc_id = (req.params.get("docId") or "").strip().upper()
    today = datetime.now(UTC).date().isoformat()

    def with_status(doc: dict[str, Any]) -> dict[str, Any]:
        return {**doc, "status": "active" if doc["validUntil"] >= today else "expired"}

    def build() -> dict[str, Any]:
        if not doc_id:
            return {"documents": [with_status(d) for d in GAF_DOCUMENTS.values()]}
        doc = GAF_DOCUMENTS.get(doc_id)
        if doc is None:
            raise GafLookupError(f"Unknown docId. Known documents: {', '.join(GAF_DOCUMENTS)}.", 404)
        return {"documents": [with_status(doc)]}

    return gaf_handler("gafGetDocuments", build)


@app.route(route="gaf/product-approval", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_product_approval(req: func.HttpRequest) -> func.HttpResponse:
    """Florida/Miami-Dade product approval registry (Data Set G).
    ?product=... required (e.g. "Timberline HDZ").

    OpenAPI operation: gafGetProductApproval.
    """
    product = (req.params.get("product") or "").strip()

    def build() -> dict[str, Any]:
        if not product:
            raise GafLookupError("The product query parameter is required.", 400)
        record = GAF_PRODUCT_APPROVAL.get(product)
        if record is None:
            raise GafLookupError(f"No approval record for product '{product}'.", 404)
        return record

    return gaf_handler("gafGetProductApproval", build)


@app.route(route="gaf/warranty-rules", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_warranty_rules(req: func.HttpRequest) -> func.HttpResponse:
    """Warranty tier requirements (Data Set H). ?tier=... ("Standard
    Limited" or "WindProven") for one tier, otherwise both.

    OpenAPI operation: gafGetWarrantyRules.
    """
    tier = (req.params.get("tier") or "").strip()

    def build() -> dict[str, Any]:
        if not tier:
            return {"tiers": list(GAF_WARRANTY_RULES.values())}
        record = GAF_WARRANTY_RULES.get(tier)
        if record is None:
            raise GafLookupError(f"Unknown tier. Known tiers: {', '.join(GAF_WARRANTY_RULES)}.", 404)
        return {"tiers": [record]}

    return gaf_handler("gafGetWarrantyRules", build)


@app.route(route="gaf/escalation-rules", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def gaf_escalation_rules(req: func.HttpRequest) -> func.HttpResponse:
    """The full escalation-rules table (Data Set I) -- always returned in
    full; it's four fixed rows, and deciding which row a given question
    matches is the calling app/agent's job, not this API's.

    OpenAPI operation: gafGetEscalationRules.
    """
    return gaf_handler("gafGetEscalationRules", lambda: {"rules": GAF_ESCALATION_RULES})
